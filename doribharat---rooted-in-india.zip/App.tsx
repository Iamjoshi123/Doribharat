
import React, { useState, useEffect, useMemo } from 'react';
import { HashRouter as Router, Routes, Route, Link, NavLink } from 'react-router-dom';
import { Product, CartItem, User, UserRole, Category, HomepageConfig } from './types';
import { INITIAL_PRODUCTS, INITIAL_CATEGORIES, INITIAL_HOMEPAGE_CONFIG, WHATSAPP_NUMBER } from './constants';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import ProductDetail from './pages/ProductDetail';
import Admin from './pages/Admin';
import CategoryPage from './pages/CategoryPage';

const App: React.FC = () => {
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('doribharat_products');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  const [categories, setCategories] = useState<Category[]>(() => {
    const saved = localStorage.getItem('doribharat_categories');
    return saved ? JSON.parse(saved) : INITIAL_CATEGORIES;
  });

  const [homepageConfig, setHomepageConfig] = useState<HomepageConfig>(() => {
    const saved = localStorage.getItem('doribharat_homepage');
    return saved ? JSON.parse(saved) : INITIAL_HOMEPAGE_CONFIG;
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('doribharat_cart');
    return saved ? JSON.parse(saved) : [];
  });

  const [wishlist, setWishlist] = useState<string[]>(() => {
    const saved = localStorage.getItem('doribharat_wishlist');
    return saved ? JSON.parse(saved) : [];
  });

  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('doribharat_user');
    return saved ? JSON.parse(saved) : null;
  });

  useEffect(() => {
    localStorage.setItem('doribharat_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('doribharat_categories', JSON.stringify(categories));
  }, [categories]);

  useEffect(() => {
    localStorage.setItem('doribharat_homepage', JSON.stringify(homepageConfig));
  }, [homepageConfig]);

  useEffect(() => {
    localStorage.setItem('doribharat_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('doribharat_wishlist', JSON.stringify(wishlist));
  }, [wishlist]);

  // Only show visible products to users
  const visibleProducts = useMemo(() => products.filter(p => p.isVisible), [products]);

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const updateCartQty = (id: string, qty: number) => {
    if (qty <= 0) {
      removeFromCart(id);
      return;
    }
    setCart(prev => prev.map(item => item.id === id ? { ...item, quantity: qty } : item));
  };

  const toggleWishlist = (id: string) => {
    setWishlist(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  const handleAdminLogin = (username: string) => {
    const newUser = { id: 'admin1', username, role: UserRole.ADMIN };
    setUser(newUser);
    localStorage.setItem('doribharat_user', JSON.stringify(newUser));
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('doribharat_user');
  };

  return (
    <Router>
      <div className="min-h-screen flex flex-col bg-[#FDFCF9]">
        <Navbar 
          cartCount={cart.reduce((acc, item) => acc + item.quantity, 0)} 
          wishlistCount={wishlist.length}
          user={user}
          onLogout={handleLogout}
        />
        
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home products={visibleProducts} categories={categories} homepageConfig={homepageConfig} onAddToCart={addToCart} onToggleWishlist={toggleWishlist} wishlist={wishlist} />} />
            <Route path="/product/:id" element={<ProductDetail products={visibleProducts} onAddToCart={addToCart} onToggleWishlist={toggleWishlist} wishlist={wishlist} />} />
            <Route path="/category/:name" element={<CategoryPage products={visibleProducts} onAddToCart={addToCart} onToggleWishlist={toggleWishlist} wishlist={wishlist} />} />
            <Route path="/cart" element={<CartPage cart={cart} updateQty={updateCartQty} remove={removeFromCart} />} />
            <Route path="/admin" element={
              <Admin 
                user={user} 
                products={products} 
                categories={categories}
                homepageConfig={homepageConfig}
                onLogin={handleAdminLogin} 
                onUpdateProducts={setProducts} 
                onUpdateCategories={setCategories}
                onUpdateHomepage={setHomepageConfig}
              />
            } />
          </Routes>
        </main>

        <footer className="bg-white border-t border-stone-100 py-24 px-8">
          <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-16">
            <div className="col-span-1 md:col-span-2">
              <h2 className="text-3xl font-bold mb-6 serif text-[#A62C2B]">doribharat</h2>
              <p className="max-w-md text-stone-400 font-light leading-relaxed">
                We believe that bags are more than accessories—they are vessels of culture. Every Doribharat bag is handcrafted by artisans who have perfected the art of Dori work over generations.
              </p>
            </div>
            <div>
              <h3 className="text-[10px] uppercase tracking-[0.3em] font-bold mb-6 text-stone-900">Collections</h3>
              <ul className="space-y-4 text-stone-500 font-light text-sm">
                {categories.slice(0, 4).map(cat => (
                  <li key={cat.id}><Link to={`/category/${cat.name}`} className="hover:text-[#A62C2B] transition-colors">{cat.name}</Link></li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="text-[10px] uppercase tracking-[0.3em] font-bold mb-6 text-stone-900">Contact Us</h3>
              <p className="text-stone-500 font-light text-sm mb-2">WhatsApp: +91 98765 43210</p>
              <p className="text-stone-500 font-light text-sm mb-4">Email: hello@doribharat.com</p>
            </div>
          </div>
          <div className="max-w-7xl mx-auto mt-24 pt-8 border-t border-stone-50 text-center text-[10px] uppercase tracking-widest text-stone-300">
            © {new Date().getFullYear()} Doribharat Artisanal Bags. Crafted with Love in India.
          </div>
        </footer>
      </div>
    </Router>
  );
};

const CartPage: React.FC<{ cart: CartItem[], updateQty: (id: string, qty: number) => void, remove: (id: string) => void }> = ({ cart, updateQty, remove }) => {
  const total = cart.reduce((acc, item) => acc + (item.sellingPrice * item.quantity), 0);
  
  const handleWhatsAppCheckout = () => {
    const itemsText = cart.map(item => `• ${item.name} (${item.quantity}x) - ₹${item.sellingPrice}`).join('%0A');
    const message = `Hello Doribharat! I would like to order these bags:%0A%0A${itemsText}%0A%0ATotal Amount: ₹${total}%0A%0APlease let me know the next steps for delivery.`;
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${message}`, '_blank');
  };

  if (cart.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-8 py-32 text-center">
        <h2 className="text-4xl serif mb-6">Your bag is empty</h2>
        <p className="text-stone-400 font-light mb-12">Carry your heritage. Start your collection today.</p>
        <Link to="/" className="inline-block border-b-2 border-[#A62C2B] text-stone-900 pb-1 font-semibold hover:text-[#A62C2B] transition-colors">Go Back to Shop</Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-8 py-20">
      <h2 className="text-4xl serif mb-16 border-b border-stone-100 pb-8">Your Collection</h2>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-20">
        <div className="lg:col-span-2 space-y-8">
          {cart.map(item => (
            <div key={item.id} className="group flex gap-8 items-center pb-8 border-b border-stone-50">
              <div className="w-24 h-32 rounded-2xl overflow-hidden bg-stone-50">
                <img src={item.images[0]} alt={item.name} className="w-full h-full object-cover" />
              </div>
              <div className="flex-grow">
                <h3 className="font-medium text-lg text-stone-800">{item.name}</h3>
                <p className="text-stone-400 text-xs uppercase tracking-widest mt-1">{item.category}</p>
                <div className="flex items-center gap-6 mt-4">
                  <div className="flex items-center bg-stone-50 rounded-full px-2">
                    <button onClick={() => updateQty(item.id, item.quantity - 1)} className="w-8 h-8 flex items-center justify-center text-stone-400 hover:text-stone-900 transition-colors">-</button>
                    <span className="w-8 text-center text-sm font-semibold">{item.quantity}</span>
                    <button onClick={() => updateQty(item.id, item.quantity + 1)} className="w-8 h-8 flex items-center justify-center text-stone-400 hover:text-stone-900 transition-colors">+</button>
                  </div>
                  <span className="font-bold text-stone-900">₹{item.sellingPrice * item.quantity}</span>
                </div>
              </div>
              <button onClick={() => remove(item.id)} className="text-stone-300 hover:text-red-400 p-2 transition-colors">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
          ))}
        </div>
        
        <div className="bg-white p-10 rounded-[3rem] border border-stone-100 shadow-sm h-fit sticky top-28">
          <h3 className="text-xl serif mb-8">Summary</h3>
          <div className="space-y-4 text-stone-500 font-light">
            <div className="flex justify-between">
              <span>Subtotal</span>
              <span className="text-stone-900">₹{total}</span>
            </div>
            <div className="flex justify-between">
              <span>Shipping</span>
              <span className="text-green-600 font-medium">Complimentary</span>
            </div>
            <div className="border-t border-stone-50 pt-6 mt-6 flex justify-between text-xl text-stone-900 font-bold">
              <span>Total</span>
              <span>₹{total}</span>
            </div>
          </div>
          <button 
            onClick={handleWhatsAppCheckout}
            className="w-full mt-10 bg-[#A62C2B] text-white py-5 rounded-full font-bold flex items-center justify-center gap-3 hover:bg-[#8e2525] transition-all shadow-xl active:scale-95"
          >
            Order via WhatsApp
          </button>
          <p className="mt-6 text-[10px] text-stone-300 text-center uppercase tracking-widest">Secure Handcrafted Delivery</p>
        </div>
      </div>
    </div>
  );
};

export default App;
