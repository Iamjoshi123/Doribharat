
# Doribharat E-Commerce Documentation

## Architecture Principles
1. **Frontend-First:** This is a React SPA built with TypeScript and Tailwind CSS.
2. **State Management:** Currently using LocalStorage and React State for persistence (Mocked Backend).
3. **Ordering Logic:** We bypass traditional payment gateways in favor of a direct WhatsApp checkout to cater to high-touch artisanal sales.

## Data Schema (Proposed for Backend)

### 1. Products Table
| Column | Type | Description |
| :--- | :--- | :--- |
| id | UUID (PK) | Unique identifier |
| name | String | Product name |
| description | Text | Detailed description |
| retail_price | Decimal | Original MSRP |
| selling_price | Decimal | Discounted price |
| stock | Integer | Available quantity |
| category_id | UUID (FK) | Reference to Categories |
| images | JSONB/Array | List of image URLs |
| metadata | JSONB | Flags like `is_new`, `is_best_seller` |

### 2. Categories Table
| Column | Type | Description |
| :--- | :--- | :--- |
| id | UUID (PK) | Unique identifier |
| name | String | Category display name |
| image_url | String | Hero image for category |

### 3. Orders Table (If captured)
| Column | Type | Description |
| :--- | :--- | :--- |
| id | UUID (PK) | Unique identifier |
| user_id | UUID (FK) | Reference to Users |
| items | JSONB | Snapshot of cart items |
| status | Enum | PENDING, SHIPPED, DELIVERED |
| wa_chat_id | String | Reference to WhatsApp conversation |

## Style Principles
- **Color Palette:** Rooted in Earth tones (#A62C2B, #3D5A2F).
- **Typography:** Modern Sans (Plus Jakarta Sans) for readability, Classic Serif (DM Serif) for heritage feel.
- **Interactions:** Use Tailwind transitions for smooth scale and opacity changes on hover.
